/* External dependency loader.
   Keeps vendor SDK <script> tags out of index.html while preserving the existing app. */
(function () {
    'use strict';

    const cssUrls = [
        'https://cdn.plyr.io/3.7.8/plyr.css'
    ];
    const scriptGroups = [
        [
            'https://cdnjs.cloudflare.com/ajax/libs/firebase/10.12.0/firebase-app-compat.min.js'
        ],
        [
            'https://cdnjs.cloudflare.com/ajax/libs/firebase/10.12.0/firebase-auth-compat.min.js'
        ],
        [
            'https://cdnjs.cloudflare.com/ajax/libs/firebase/10.12.0/firebase-database-compat.min.js'
        ],
        [
            'https://cdn.plyr.io/3.7.8/plyr.polyfilled.js',
            'https://cdn.jsdelivr.net/npm/plyr@3.7.8/dist/plyr.polyfilled.min.js'
        ],
        [
            'https://cdn.jsdelivr.net/npm/hls.js@latest',
            'https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js'
        ]
    ];

    function addCss(url) {
        return new Promise(resolve => {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = url;
            link.onload = () => resolve(true);
            link.onerror = () => resolve(false);
            document.head.appendChild(link);
        });
    }

    function addScript(url) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = url;
            script.async = false;
            script.onload = () => resolve(true);
            script.onerror = () => reject(new Error('Failed to load ' + url));
            document.head.appendChild(script);
        });
    }

    async function loadOneOf(urls) {
        for (const url of urls) {
            try {
                await addScript(url);
                return true;
            } catch (e) {}
        }
        return false;
    }

    async function boot() {
        cssUrls.forEach(addCss);

        for (const group of scriptGroups) {
            await loadOneOf(group);
        }

        await addScript('js/firebase-runtime.js?v=20260921-playercards5');

        const app = document.createElement('script');
        app.src = 'js/app.js?v=20260921-playercards5';
        app.async = false;
        document.body.appendChild(app);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
    } else {
        boot();
    }
}());
