/* ==========================================
   FIREBASE RUNTIME CONFIGURATION
   Loaded before app.js by vendor-loader.js.
========================================== */
const firebaseConfig = {
  apiKey:'AIzaSyAgOOC2KUhTSm08NuMztHUlokVsqMnyK3U',
  authDomain:'terabox-video-player-13c5a.firebaseapp.com',
  databaseURL:'https://terabox-video-player-13c5a-default-rtdb.firebaseio.com',
  projectId:'terabox-video-player-13c5a',
  storageBucket:'terabox-video-player-13c5a.firebasestorage.app',
  messagingSenderId:'757397549041',
  appId:'1:757397549041:web:b59ff12756a7adcb645e50',
  measurementId:'G-N2VHVGTSMJ'
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

window.teraFirebaseLoadSaved = function(uid) {
  return db.ref('users/' + uid + '/saved').once('value');
};

window.teraFirebaseSave = function(uid, key, value) {
  return db.ref('users/' + uid + '/saved/' + key).set(value);
};

window.teraFirebaseRemoveSaved = function(uid, key) {
  return db.ref('users/' + uid + '/saved/' + key).remove();
};

window.teraFirebaseVideos = function() {
  return db.ref('videoMeta').once('value');
};

window.teraFirebaseIncrementView = function(key) {
  return db.ref('videoMeta/' + key + '/viewCount').transaction(current => (current || 0) + 1);
};
