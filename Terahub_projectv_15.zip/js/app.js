/* ==========================================
   SINGLE API KEY
========================================== */
const TERABOX_API_KEY = 'xapi_54f6f5250cf502883378e6f41a4d0fc6'
const TERABOX_API_URL = 'https://xapiverse.com/api/terabox'

/* ==========================================
   APP STATE
========================================== */
let allVideos = [];
let filteredVideos = [];
let currentVideoIndex = -1;
let currentTab = 'foryou';
let currentUser = null;
// REQ #7: track a pending action when user needs to log in first
let pendingAction = null;
// REQ #3: in-memory saved set (Firebase-backed when logged in)
let savedVideoKeys = new Set();
// REQ #4: deduplicated video identity tracker
let seenVideoIdentities = new Set();
let sharedVideoId = '';
const VIDEO_CACHE_KEY = 'terastream_video_meta_cache_v1';

/* ==========================================
   DOM HELPERS
========================================== */
const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

/* ==========================================
   AUTH PAGE SWITCHER
========================================== */
function showPage(pageId) {
    $$('.auth-page').forEach(p => p.classList.remove('active'));
    const pg = document.getElementById(pageId);
    if (pg) pg.classList.add('active');
    clearAuthErrors();
}

function clearAuthErrors() {
    ['loginError','signupError','forgotError','modalLoginError'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.classList.remove('show');
    });
    const fs = document.getElementById('forgotSuccess');
    if (fs) fs.classList.remove('show');
}

function showAuthError(prefix, msg) {
    const el = document.getElementById(prefix + 'Error');
    const msgEl = document.getElementById(prefix + 'ErrorMsg');
    if (el && msgEl) { msgEl.textContent = msg; el.classList.add('show'); }
}

function togglePass(inputId, eyeEl) {
    const inp = document.getElementById(inputId);
    if (!inp) return;
    const isHidden = inp.type === 'password';
    inp.type = isHidden ? 'text' : 'password';
    eyeEl.innerHTML = isHidden ? '<i class="fas fa-eye-slash"></i>' : '<i class="fas fa-eye"></i>';
}

function setBtnLoading(btnId, loading, label) {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    btn.disabled = loading;
    if (loading) {
        btn.dataset.origText = btn.innerHTML;
        btn.innerHTML = '<div class="spin-ring" style="width:18px;height:18px;border-width:2px;margin:0;"></div>';
    } else {
        btn.innerHTML = btn.dataset.origText || label || btn.innerHTML;
    }
}

/* ==========================================
   REQ #7: LOGIN MODAL — shown on demand
========================================== */
function showLoginModal(actionCallback) {
    pendingAction = actionCallback || null;
    const overlay = document.getElementById('authModalOverlay');
    if (overlay) overlay.classList.add('active');
    const emailEl = document.getElementById('modalLoginEmail');
    const passEl = document.getElementById('modalLoginPassword');
    if (emailEl) emailEl.value = '';
    if (passEl) passEl.value = '';
    const errEl = document.getElementById('modalLoginError');
    if (errEl) errEl.classList.remove('show');
}

function closeLoginModal() {
    const overlay = document.getElementById('authModalOverlay');
    if (overlay) overlay.classList.remove('active');
    pendingAction = null;
}

function doModalLogin() {
    const email = (document.getElementById('modalLoginEmail').value || '').trim();
    const pass = (document.getElementById('modalLoginPassword').value || '').trim();
    if (!email || !pass) { showAuthError('modalLogin','Please enter email and password.'); return; }
    setBtnLoading('modalLoginBtn', true);
    const actionAfterLogin = pendingAction;
    auth.signInWithEmailAndPassword(email, pass)
        .then(() => {
            setBtnLoading('modalLoginBtn', false);
            closeLoginModal();
            // Execute the exact protected action that triggered login.
            if (typeof actionAfterLogin === 'function') actionAfterLogin();
        })
        .catch(err => {
            setBtnLoading('modalLoginBtn', false);
            showAuthError('modalLogin', friendlyAuthError(err.code));
        });
}

/* ==========================================
   FIREBASE AUTH: LOGIN (full page)
========================================== */
function doLogin() {
    const email = ($('#loginEmail').value || '').trim();
    const pass = ($('#loginPassword').value || '').trim();
    if (!email || !pass) { showAuthError('login','Please enter email and password.'); return; }
    setBtnLoading('loginBtn', true);
    auth.signInWithEmailAndPassword(email, pass)
        .then(() => { setBtnLoading('loginBtn', false); })
        .catch(err => {
            setBtnLoading('loginBtn', false);
            showAuthError('login', friendlyAuthError(err.code));
        });
}

/* ==========================================
   FIREBASE AUTH: SIGN UP
========================================== */
function doSignup() {
    const name = ($('#signupName').value || '').trim();
    const email = ($('#signupEmail').value || '').trim();
    const pass = ($('#signupPassword').value || '').trim();
    const confirm = ($('#signupConfirm').value || '').trim();
    if (!name) { showAuthError('signup','Please enter your full name.'); return; }
    if (!email) { showAuthError('signup','Please enter your email.'); return; }
    if (pass.length < 6) { showAuthError('signup','Password must be at least 6 characters.'); return; }
    if (pass !== confirm) { showAuthError('signup','Passwords do not match.'); return; }
    setBtnLoading('signupBtn', true);
    auth.createUserWithEmailAndPassword(email, pass)
        .then(result => {
            return result.user.updateProfile({ displayName: name });
        })
        .then(() => {
            setBtnLoading('signupBtn', false);
            showToast('Account created! Welcome.', 'success');
        })
        .catch(err => {
            setBtnLoading('signupBtn', false);
            showAuthError('signup', friendlyAuthError(err.code));
        });
}

/* ==========================================
   FIREBASE AUTH: FORGOT PASSWORD
========================================== */
function doForgot() {
    const email = ($('#forgotEmail').value || '').trim();
    if (!email) { showAuthError('forgot','Please enter your email address.'); return; }
    setBtnLoading('forgotBtn', true);
    auth.sendPasswordResetEmail(email)
        .then(() => {
            setBtnLoading('forgotBtn', false);
            const el = document.getElementById('forgotSuccess');
            const msg = document.getElementById('forgotSuccessMsg');
            if (el && msg) { msg.textContent = 'Reset link sent! Check your email inbox.'; el.classList.add('show'); }
            document.getElementById('forgotError').classList.remove('show');
        })
        .catch(err => {
            setBtnLoading('forgotBtn', false);
            showAuthError('forgot', friendlyAuthError(err.code));
        });
}

/* ==========================================
   FIREBASE AUTH: LOGOUT
========================================== */
function doLogout() {
    auth.signOut().then(() => {
        showToast('Logged out successfully.', 'info');
        savedVideoKeys.clear();
    });
}

/* ==========================================
   FRIENDLY ERROR MESSAGES
========================================== */
function friendlyAuthError(code) {
    const map = {
        'auth/user-not-found': 'No account found with this email.',
        'auth/wrong-password': 'Incorrect password. Please try again.',
        'auth/invalid-email': 'Please enter a valid email address.',
        'auth/email-already-in-use': 'This email is already registered. Try logging in.',
        'auth/weak-password': 'Password is too weak. Use at least 6 characters.',
        'auth/too-many-requests': 'Too many attempts. Please try again later.',
        'auth/network-request-failed': 'Network error. Check your connection.',
        'auth/invalid-credential': 'Incorrect email or password.',
    };
    return map[code] || 'Something went wrong. Please try again.';
}

/* ==========================================
   REQ #7: AUTH STATE LISTENER
   - App shell always visible (no forced login on open)
   - Login page / modal only when actually needed
========================================== */
auth.onAuthStateChanged(user => {
    if (user) {
        currentUser = user;
        // Hide all auth pages, show app
        $$('.auth-page').forEach(p => p.classList.remove('active'));
        closeLoginModal();
        document.getElementById('appShell').classList.add('visible');
        if (isSharedVideoPath() && !isSharedVideoDismissed()) { const shell = document.getElementById('appShell'); if (shell) { shell.style.visibility = 'hidden'; shell.style.display = 'none'; } }

        // Update UI with user info
        const name = user.displayName || user.email || 'User';
        const initial = name.charAt(0).toUpperCase();
        const setTxt = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
        setTxt('chipName', name.split(' ')[0]);
        setTxt('pdName', name);
        setTxt('pdEmail', user.email || '');
        ['topAvatar','pdAvatar'].forEach(id => setTxt(id, initial));

        // Show logged-in nav elements, hide sign-in chip
        const userChip = document.getElementById('userChip');
        const bellBtn = document.getElementById('navBellBtn');
        const signInChip = document.getElementById('signInChip');
        if (userChip) userChip.style.display = 'flex';
        if (bellBtn) bellBtn.style.display = 'flex';
        if (signInChip) signInChip.style.display = 'none';

        // Load saved videos from Firebase
        loadSavedVideos();

        // Load videos if not loaded yet
        if (!allVideos.length) {
            buildSkeletons(6);
            fetchAllVideos();
        }
    } else {
        currentUser = null;
        savedVideoKeys.clear();

        // REQ #7: Show app shell (home page visible without login)
        document.getElementById('appShell').classList.add('visible');
        if (isSharedVideoPath() && !isSharedVideoDismissed()) { const shell = document.getElementById('appShell'); if (shell) { shell.style.visibility = 'hidden'; shell.style.display = 'none'; } }

        // Show sign-in chip, hide logged-in elements
        const userChip = document.getElementById('userChip');
        const bellBtn = document.getElementById('navBellBtn');
        const signInChip = document.getElementById('signInChip');
        if (userChip) userChip.style.display = 'none';
        if (bellBtn) bellBtn.style.display = 'none';
        if (signInChip) signInChip.style.display = 'flex';

        // Hide full-page auth (don't force it on open)
        $$('.auth-page').forEach(p => p.classList.remove('active'));

        // Load videos for browsing if not loaded yet
        if (!allVideos.length) {
            buildSkeletons(6);
            fetchAllVideos();
        }
    }
});

/* ==========================================
   REQ #3: LOAD SAVED VIDEOS FROM FIREBASE
========================================== */
function loadSavedVideos() {
    if (!currentUser) return;
    teraFirebaseLoadSaved(currentUser.uid).then(snap => {
        const data = snap.val();
        savedVideoKeys.clear();
        if (data) {
            Object.keys(data).forEach(k => savedVideoKeys.add(k));
        }
        // Re-render save button states if grid is visible
        updateSaveButtonStates();
    }).catch(() => {});
}

function updateSaveButtonStates() {
    $$('.va-btn.save').forEach(btn => {
        const key = btn.dataset.fbkey;
        if (key && savedVideoKeys.has(key)) {
            btn.classList.add('saved');
            btn.title = 'Saved';
            btn.innerHTML = '<i class="fas fa-bookmark"></i>';
        } else {
            btn.classList.remove('saved');
            btn.title = 'Save';
            btn.innerHTML = '<i class="far fa-bookmark"></i>';
        }
    });
}

/* ==========================================
   REQ #3: SAVE VIDEO
========================================== */
function saveVideo(index, btnEl) {
    // REQ #7: require login for save
    if (!currentUser) {
        showLoginModal(() => saveVideo(index, null));
        return;
    }
    const video = allVideos[index];
    if (!video) return;
    const key = video._fbKey;
    const ref = {
        remove: () => teraFirebaseRemoveSaved(currentUser.uid, key),
        set: value => teraFirebaseSave(currentUser.uid, key, value)
    };
    if (savedVideoKeys.has(key)) {
        // Unsave
        ref.remove().then(() => {
            savedVideoKeys.delete(key);
            if (btnEl) {
                btnEl.classList.remove('saved');
                btnEl.title = 'Save';
                btnEl.innerHTML = btnEl.id === 'detailSaveBtn' ? '<i class="far fa-bookmark"></i> Save' : '<i class="far fa-bookmark"></i>';
            }
            showToast('Removed from saved.', 'info');
        }).catch(() => showToast('Could not remove. Try again.','error'));
    } else {
        // Save
        ref.set({ savedAt: Date.now(), name: video.name || '' }).then(() => {
            savedVideoKeys.add(key);
            if (btnEl) {
                btnEl.classList.add('saved');
                btnEl.title = 'Saved';
                btnEl.innerHTML = btnEl.id === 'detailSaveBtn' ? '<i class="fas fa-bookmark"></i> Saved' : '<i class="fas fa-bookmark"></i>';
            }
            showToast('Saved!', 'success');
        }).catch(() => showToast('Could not save. Try again.','error'));
    }
}

/* ==========================================
   EVENTS
========================================== */
function findSharedVideoIndex(rawUrl) {
    const raw = String(rawUrl || '').trim();
    if (!/^https?:\/\//i.test(raw)) return -1;

    const normalizeUrl = value => String(value || '').trim().replace(/\/+$/, '').toLowerCase();
    const urlPathKey = value => {
        const normalized = normalizeUrl(value);
        if (!normalized) return '';
        try {
            const u = new URL(normalized);
            return (u.hostname + u.pathname).replace(/\/+$/, '');
        } catch (e) {
            return normalized.replace(/^https?:\/\//i, '').split(/[?#]/)[0].replace(/\/+$/, '');
        }
    };

    let parsed;
    try { parsed = new URL(raw); } catch (e) { return -1; }
    const normalizedShared = normalizeUrl(raw);
    const sharedPathKey = urlPathKey(raw);
    const parts = parsed.pathname.split('/').filter(Boolean);
    const normalizedId = String(parts[parts.length - 1] || '').trim().replace(/^--+/, '').toLowerCase();

    return allVideos.findIndex(v => {
        const videoId = String(v.videoId || v.video_id || v.id || v._fbKey || '').trim().replace(/^--+/, '').toLowerCase();
        const sourceRaw = v.sourceUrl || v.source_url || '';
        const downloadRaw = v.downloadUrl || v.download_url || '';
        const sourceUrl = normalizeUrl(sourceRaw);
        const downloadUrl = normalizeUrl(downloadRaw);
        const sourcePathKey = urlPathKey(sourceRaw);
        const downloadPathKey = urlPathKey(downloadRaw);
        return (normalizedShared && (sourceUrl === normalizedShared || downloadUrl === normalizedShared)) ||
               (sharedPathKey && (sourcePathKey === sharedPathKey || downloadPathKey === sharedPathKey)) ||
               videoId === normalizedId;
    });
}

function bindEvents() {
    const searchEl = document.getElementById('searchInput');
    if (searchEl) {
        searchEl.addEventListener('input', debounce(e => {
            const raw = e.target.value.trim();
            const q = raw.toLowerCase();
            const isUrl = /^https?:\/\//i.test(raw);
            if (isUrl) {
                const idx = findSharedVideoIndex(raw);
                if (idx >= 0) {
                    const shell = document.getElementById('appShell');
                    if (shell) { shell.style.visibility = 'hidden'; shell.style.display = 'none'; }
                    showSharedVideoModal(idx);
                    return;
                }
            }
            filteredVideos = q ? allVideos.filter(v =>
                (v.name||'').toLowerCase().includes(q) ||
                String(v.videoId||v.video_id||v.id||'').toLowerCase().includes(q) ||
                String(v.sourceUrl||v.source_url||'').toLowerCase().includes(q) ||
                String(v.downloadUrl||v.download_url||'').toLowerCase().includes(q)
            ) : [...allVideos];
            renderGrid(getTabVideos(currentTab));
        }, 250));
    }

    $$('.tab-pill[data-tab]').forEach(tab => {
        tab.addEventListener('click', function() {
            $$('.tab-pill[data-tab]').forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected','false'); });
            this.classList.add('active'); this.setAttribute('aria-selected','true');
            currentTab = this.dataset.tab;
            renderGrid(getTabVideos(currentTab));
        });
    });

    const backBtn = document.getElementById('backBtn');
    if (backBtn) backBtn.addEventListener('click', backToHome);

    $$('.bnav-item').forEach(item => {
        item.addEventListener('click', function() {
            $$('.bnav-item').forEach(n => n.classList.remove('active'));
            this.classList.add('active');
            switchView('homeView');
            $$('.bnav-item')[0].classList.add('active');
        });
    });

    document.addEventListener('click', e => {
        const chip = document.getElementById('userChip');
        const dd = document.getElementById('profileDropdown');
        if (chip && dd && !chip.contains(e.target)) dd.classList.remove('open');
    });

    // Enter key on auth inputs
    const lpEl = document.getElementById('loginPassword');
    const scEl = document.getElementById('signupConfirm');
    const feEl = document.getElementById('forgotEmail');
    const mlEl = document.getElementById('modalLoginPassword');
    if (lpEl) lpEl.addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
    if (scEl) scEl.addEventListener('keydown', e => { if (e.key === 'Enter') doSignup(); });
    if (feEl) feEl.addEventListener('keydown', e => { if (e.key === 'Enter') doForgot(); });
    if (mlEl) mlEl.addEventListener('keydown', e => { if (e.key === 'Enter') doModalLogin(); });

    // Close modal on overlay click
    const overlay = document.getElementById('authModalOverlay');
    if (overlay) {
        overlay.addEventListener('click', e => {
            if (e.target === overlay) closeLoginModal();
        });
    }

    // Share modal and page-source-safe actions.
    document.addEventListener('click', e => {
        const actionEl = e.target.closest('[data-action]');
        if (!actionEl) return;
        const action = actionEl.dataset.action;
        if (action === 'toggle-pass') togglePass(actionEl.dataset.input, actionEl);
        else if (action === 'show-page') showPage(actionEl.dataset.page);
        else if (action === 'login') doLogin();
        else if (action === 'signup') doSignup();
        else if (action === 'forgot') doForgot();
        else if (action === 'close-login-modal') closeLoginModal();
        else if (action === 'modal-login') doModalLogin();
        else if (action === 'modal-create-account') { closeLoginModal(); showPage('signupPage'); }
        else if (action === 'notifications') showToast('No new notifications','info');
        else if (action === 'profile-toggle') toggleProfileDropdown();
        else if (action === 'profile-menu') e.stopPropagation();
        else if (action === 'settings') showToast('Settings coming soon','info');
        else if (action === 'logout') doLogout();
        else if (action === 'show-login') showLoginModal(null);
        else if (action === 'share-current') shareCurrent();
        else if (action === 'detail-report') showToast('Report submitted','info');
        else if (action === 'save-current') saveCurrent();
        else if (action === 'close-share-modal') closeShareModal();
        else if (action === 'copy-share-link') copyShareLink();
    });

    $$('#shareModalOverlay [data-share]').forEach(btn => {
        btn.addEventListener('click', () => shareVia(btn.dataset.share));
    });

    const shareOverlay = document.getElementById('shareModalOverlay');
    if (shareOverlay) {
        shareOverlay.addEventListener('click', e => {
            if (e.target === shareOverlay) closeShareModal();
        });
    }
    const shareCloseBtn = document.querySelector('.share-modal-close');
    if (shareCloseBtn) shareCloseBtn.addEventListener('click', e => {
        e.preventDefault();
        e.stopPropagation();
        closeShareModal();
    });
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') closeShareModal();
    });
}

/* ==========================================
   PROFILE DROPDOWN
========================================== */
function toggleProfileDropdown() {
    document.getElementById('profileDropdown').classList.toggle('open');
}

/* ==========================================
   VIEW SWITCH
========================================== */
function switchView(viewId) {
    $$('.view').forEach(v => v.classList.remove('active'));
    const t = document.getElementById(viewId);
    if (t) t.classList.add('active');
}

/* ==========================================
   SKELETONS
========================================== */
function buildSkeletons(count) {
    let h = '';
    for (let i = 0; i < count; i++) {
        h += `<div class="skel-card"><div class="skel-thumb"></div><div class="skel-body"><div class="skel-line w100"></div><div class="skel-line w75"></div><div class="skel-line w50"></div></div></div>`;
    }
    const sg = document.getElementById('skelGrid');
    if (sg) { sg.innerHTML = h; sg.style.display = 'flex'; }
}

/* ==========================================
   REQ #4: VIDEO IDENTITY for deduplication
   Identity = sourceUrl or downloadUrl or name (fallback)
========================================== */
function getVideoIdentityKeys(v) {
    // Deduplicate by real video identity/link/details, never by title alone.
    const keys = [];
    const add = value => {
        const key = String(value || '').trim().toLowerCase();
        if (key) keys.push(key);
    };
    add(v.videoId || v.video_id || v.id);
    add(v.sourceUrl || v.source_url);
    add(v.downloadUrl || v.download_url);
    if (!keys.length) {
        add([v.thumbnail || '', v.duration || '', v.size || v.size_formatted || '', v.format || ''].join('|'));
    }
    return [...new Set(keys)];
}

/* ==========================================
   FETCH ALL VIDEOS FROM FIREBASE REALTIME DB
   REQ #5 / #11: NO stream URL fetched here — only metadata
   REQ #4: Deduplicate by sourceUrl/downloadUrl/identity
========================================== */
function fetchAllVideos() {
    // Render the last known metadata immediately, then refresh from Firebase in the background.
    try {
        const cached = JSON.parse(localStorage.getItem(VIDEO_CACHE_KEY) || 'null');
        if (Array.isArray(cached) && cached.length) {
            allVideos = cached.map(v => ({ ...v, stream_url:'', fast_dlink:'', fast_stream_url:{}, _urlFetched:false }));
            filteredVideos = [...allVideos];
            renderGrid(getTabVideos(currentTab));
            handleSharedVideoPath();
        }
    } catch (e) {}

    teraFirebaseVideos()
        .then(snapshot => {
            const data = snapshot.val();
            if (!data) {
                if (!allVideos.length) showError('No videos found in database.');
                return;
            }

            const videos = [];
            seenVideoIdentities.clear();

            Object.entries(data).forEach(([key, entry]) => {
                const v = entry.apiResponse ? { ...entry, ...entry.apiResponse } : entry;

                // REQ #4: Deduplicate when ANY real video identity/link matches.
                const identityKeys = getVideoIdentityKeys({
                    videoId: v.videoId || entry.videoId || v.video_id || entry.video_id || v.id || entry.id || '',
                    sourceUrl: v.sourceUrl || entry.sourceUrl || '',
                    downloadUrl: v.downloadUrl || entry.downloadUrl || '',
                    thumbnail: v.thumbnail || entry.thumbnail || '',
                    duration: v.duration || entry.duration || '',
                    size: v.size || entry.size || '',
                    format: v.format || entry.format || ''
                });
                if (identityKeys.some(identity => seenVideoIdentities.has(identity))) return;
                identityKeys.forEach(identity => seenVideoIdentities.add(identity));

                videos.push({
                    _fbKey: key,
                    videoId: v.videoId || entry.videoId || v.video_id || entry.video_id || v.id || entry.id || key,
                    name: v.name || entry.name || 'Untitled',
                    size_formatted: v.size || entry.size || '',
                    duration: v.duration || entry.duration || '',
                    thumbnail: v.thumbnail || entry.thumbnail || '',
                    sourceUrl: v.sourceUrl || entry.sourceUrl || '',
                    downloadUrl: v.downloadUrl || entry.downloadUrl || '',
                    createdAt: v.createdAt || entry.createdAt || null,
                    fetchedAt: v.fetchedAt || entry.fetchedAt || null,
                    format: v.format || entry.format || '',
                    viewCount: v.viewCount || entry.viewCount || 0,
                    // REQ #5: stream links start empty — fetched ONLY on click
                    stream_url: '',
                    fast_dlink: '',
                    fast_stream_url: {},
                    _urlFetched: false,
                });
            });

            allVideos = videos;
            filteredVideos = [...allVideos];

            try {
                const cacheable = allVideos.map(v => ({
                    _fbKey:v._fbKey, videoId:v.videoId, name:v.name, size_formatted:v.size_formatted,
                    duration:v.duration, thumbnail:v.thumbnail, sourceUrl:v.sourceUrl, downloadUrl:v.downloadUrl,
                    createdAt:v.createdAt, fetchedAt:v.fetchedAt, format:v.format, viewCount:v.viewCount
                }));
                localStorage.setItem(VIDEO_CACHE_KEY, JSON.stringify(cacheable));
            } catch (e) {}

            if (allVideos.length) {
                renderGrid(getTabVideos(currentTab));
                handleSharedVideoPath();
            } else {
                showError('No videos found. Add videos to Firebase.');
            }
        })
        .catch(() => {
            showError('Could not load videos. Check your connection.');
        });
}

function showError(msg) {
    const sg = document.getElementById('skelGrid');
    const es = document.getElementById('emptyState');
    if (sg) sg.style.display = 'none';
    if (es) {
        es.style.display = 'block';
        es.className = 'state-box error';
        es.innerHTML = `<i class="fas fa-exclamation-triangle"></i><p>${msg}</p>`;
    }
}

document.getElementById('sharedVideoModalClose')?.addEventListener('click', dismissSharedVideoModal);
document.getElementById('sharedVideoModalOverlay')?.addEventListener('click', e => {
    if (e.target.id === 'sharedVideoModalOverlay') closeSharedVideoModal();
});

/* ==========================================
   TAB VIDEO LOGIC
========================================== */
function getTabVideos(tab) {
    const base = filteredVideos.length ? filteredVideos : allVideos;
    if (!base.length) return [];
    if (tab === 'foryou') return [...base].sort(() => Math.random() - 0.5);
    if (tab === 'recent') return [...base].slice().reverse();
    if (tab === 'trending') {
        const t = base.filter((_,i) => i % 3 === 0);
        return t.length ? t : base.slice(0, Math.max(1, Math.floor(base.length/2)));
    }
    if (tab === 'popular') {
        const p = base.filter((_,i) => i % 2 === 0);
        return p.length ? p : base;
    }
    if (tab === 'premium') {
        return base.slice(0, Math.min(3, base.length));
    }
    return base;
}

/* ==========================================
   RENDER GRID
   REQ #3: Shows view count + Save button
   REQ #5: No stream fetch here
========================================== */
function renderGrid(videos) {
    const sg = document.getElementById('skelGrid');
    const grid = document.getElementById('videoGrid');
    const es = document.getElementById('emptyState');
    if (sg) sg.style.display = 'none';
    if (grid) grid.innerHTML = '';
    if (es) es.style.display = 'none';

    if (!videos || !videos.length) {
        if (es) {
            es.style.display = 'block';
            es.className = 'state-box empty';
            es.innerHTML = '<i class="fas fa-film"></i><p>No videos found. Try a different search.</p>';
        }
        return;
    }

    if (grid) grid.style.display = 'flex';

    videos.forEach((video) => {
        const realIdx = allVideos.indexOf(video);
        const isPrem = currentTab === 'premium';

        let badgeHtml = '';
        if (isPrem) {
            badgeHtml = '<span class="v-badge vb-premium-tag"><i class="fas fa-crown"></i> Premium</span>';
        } else if (currentTab === 'trending') {
            badgeHtml = '<span class="v-badge vb-trending"><i class="fas fa-fire"></i> Trending</span>';
        } else if (currentTab === 'popular') {
            badgeHtml = '<span class="v-badge vb-popular"><i class="fas fa-bolt"></i> Popular</span>';
        } else if (currentTab === 'foryou') {
            badgeHtml = '';
        } else if (currentTab === 'recent') {
            badgeHtml = '<span class="v-badge vb-recent"><i class="fas fa-clock"></i> Recent</span>';
        }

        const durHtml = video.duration ? `<span class="vb-duration">${escHtml(video.duration)}</span>` : '';
        const qualityValue = String(video.format || '').trim();
        const qualityHtml = /^\d{3,4}p$/i.test(qualityValue) ? `<span class="vb-quality">${escHtml(qualityValue.toUpperCase())}</span>` : '';
        const dateStr = video.createdAt ? formatRelativeDate(video.createdAt) : (video.fetchedAt ? formatRelativeDate(video.fetchedAt) : '');

        // REQ #3: view count — use actual viewCount from DB, display only if > 0
        const viewCountNum = parseInt(video.viewCount) || 0;
        const viewCountHtml = `<span class="vcard-views"><i class="fas fa-eye"></i>${formatViewCount(viewCountNum)}</span>`;
        const sizeMetaHtml = video.size_formatted ? `<span class="vcard-size">${escHtml(video.size_formatted)}</span>` : '';
        const dateMetaHtml = dateStr ? `<span class="vcard-date">${escHtml(dateStr)}</span>` : '';

        // REQ #3: Save button — check saved state
        const isSaved = savedVideoKeys.has(video._fbKey);
        const saveIcon = isSaved ? 'fas fa-bookmark' : 'far fa-bookmark';
        const saveClass = isSaved ? 'va-btn save saved' : 'va-btn save';

        const card = document.createElement('div');
        card.className = 'vcard';
        card.dataset.videoId = video.videoId || video._fbKey;
        card.innerHTML = `
            <div class="thumb-wrap">
                <div class="thumb-skel"></div>
                <img data-src="${escHtml(video.thumbnail||'')}" alt="${escHtml(video.name||'Video')}" loading="lazy">
                <div class="thumb-grad"></div>
                ${badgeHtml}
                ${qualityHtml}
                ${durHtml}
            </div>
            <div class="vcard-body">
                <div class="vcard-title">${escHtml(video.name||'Untitled')}</div>
                <div class="vcard-meta">
                    ${viewCountHtml}
                    ${sizeMetaHtml}
                    ${dateMetaHtml}
                </div>
                <div class="vcard-actions">
                    <button class="${saveClass}" title="${isSaved ? 'Saved' : 'Save'}" aria-label="${isSaved ? 'Saved' : 'Save'}" data-fbkey="${escHtml(video._fbKey)}"><i class="${saveIcon}"></i></button>
                    <button class="va-btn share" title="Share" aria-label="Share"><i class="fas fa-share-alt"></i></button>
                    <button class="va-btn report" title="Report" aria-label="Report"><i class="fas fa-flag"></i></button>
                </div>
            </div>
        `;

        card.querySelector('.thumb-wrap').style.setProperty('--thumb-bg', video.thumbnail ? `url("${String(video.thumbnail).replace(/"/g, '\\"')}")` : 'none');
        if (grid) grid.appendChild(card);
        lazyLoad(card.querySelector('img[data-src]'), card.querySelector('.thumb-skel'));

        // REQ #5/#7: Thumbnail/title click — show the same video popup used by shared links.
        const thumbClick = () => {
            showSharedVideoModal(realIdx);
        };
        card.querySelector('.thumb-wrap').addEventListener('click', thumbClick);
        card.querySelector('.vcard-title').addEventListener('click', thumbClick);

        // Share button (no auth required — opens the share panel).
        card.querySelector('.va-btn.share').addEventListener('click', e => {
            e.stopPropagation();
            shareVideo(realIdx);
        });

        // REQ #3: Save button
        const saveBtn = card.querySelector('.va-btn.save');
        saveBtn.addEventListener('click', e => {
            e.stopPropagation();
            saveVideo(realIdx, saveBtn);
        });

        card.querySelector('.va-btn.report').addEventListener('click', e => {
            e.stopPropagation();
            showToast('Report submitted. Thank you.','info');
        });
    });
}

/* ==========================================
   FORMAT VIEW COUNT
========================================== */
function formatViewCount(n) {
    if (n >= 1000000) return (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'k';
    return String(n);
}

/* ==========================================
   OPEN VIDEO PAGE
   The home page no longer contains a video player.
   The selected video is passed to video.html, which is the only player page.
========================================== */
function fetchAndOpenDetail(index) {
    const video = allVideos[index];
    if (!video) return;

    try {
        sessionStorage.setItem('terastream_selected_video', JSON.stringify(video));
    } catch (e) {
        showToast('Could not prepare this video.', 'error');
        return;
    }

    incrementViewCount(index);
    window.location.href = 'video.html';
}

/* ==========================================
   REQ #3: INCREMENT VIEW COUNT IN FIREBASE
========================================== */
function incrementViewCount(index) {
    const video = allVideos[index];
    if (!video || !video._fbKey) return;
    teraFirebaseIncrementView(video._fbKey).then(result => {
        if (result.committed) {
            const count = result.snapshot.val();
            allVideos[index].viewCount = count;
            const card = document.querySelector('[data-video-id="' + CSS.escape(String(video.videoId || video._fbKey)) + '"]');
            const viewEl = card ? card.querySelector('.vcard-views') : null;
            if (viewEl) viewEl.innerHTML = '<i class="fas fa-eye"></i>' + formatViewCount(count) + ' views';
        }
    }).catch(() => {});
}

/* ==========================================
   FORMAT DATE
========================================== */
function formatRelativeDate(ts) {
    if (!ts) return '';
    const raw = typeof ts === 'string' && !/^\d+(\.\d+)?$/.test(ts) ? ts : null;
    const d = raw ? new Date(ts) : new Date(typeof ts === 'number' && ts > 1e10 ? ts : Number(ts) * 1000);
    if (Number.isNaN(d.getTime())) return '';
    const diff = Math.max(0, Date.now() - d.getTime());
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return mins <= 1 ? 'just now' : `${mins} mins ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return hours === 1 ? '1 hour ago' : `${hours} hours ago`;
    const days = Math.floor(hours / 24);
    if (days < 30) return days === 1 ? '1 day ago' : `${days} days ago`;
    const months = Math.floor(days / 30);
    if (months < 12) return months === 1 ? '1 month ago' : `${months} months ago`;
    const years = Math.floor(months / 12);
    return years === 1 ? '1 year ago' : `${years} years ago`;
}

function formatDate(ts) {
    if (!ts) return '';
    const d = new Date(typeof ts === 'number' && ts > 1e10 ? ts : ts * 1000);
    return d.toLocaleDateString('en-US', {month:'short', day:'numeric', year:'numeric'});
}

function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

/* ==========================================
   LAZY LOAD THUMBNAILS
========================================== */
function lazyLoad(img, skelEl) {
    if (!img || !img.dataset.src) return;
    const NO_IMG = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='320' height='180'%3E%3Crect width='320' height='180' fill='%2318181b'/%3E%3Ctext x='50%25' y='50%25' fill='%2363636e' font-size='13' text-anchor='middle' dominant-baseline='middle' font-family='sans-serif'%3ENo Preview%3C/text%3E%3C/svg%3E";
    const load = () => {
        const tmp = new Image();
        tmp.onload = () => { img.src = img.dataset.src; img.classList.add('loaded'); if (skelEl) skelEl.classList.add('hide'); };
        tmp.onerror = () => { img.src = NO_IMG; img.classList.add('loaded'); if (skelEl) skelEl.classList.add('hide'); };
        tmp.src = img.dataset.src;
    };
    if ('IntersectionObserver' in window) {
        const obs = new IntersectionObserver((entries, o) => {
            entries.forEach(e => { if (e.isIntersecting) { load(); o.unobserve(e.target); } });
        }, { rootMargin:'300px' });
        obs.observe(img);
    } else load();
}

function showSharedVideoLoading() {
    const overlay = document.getElementById('sharedVideoModalOverlay');
    const image = document.getElementById('sharedVideoModalImage');
    const title = document.getElementById('sharedVideoModalName');
    const modalTitle = document.getElementById('sharedVideoModalTitle');
    const meta = document.getElementById('sharedVideoModalMeta');
    const watchBtn = document.getElementById('sharedVideoWatchBtn');
    const thumb = document.getElementById('sharedVideoModalThumb');
    if (!overlay) return;
    if (modalTitle) modalTitle.textContent = 'Video';
    if (title) title.textContent = 'Loading video...';
    if (meta) meta.innerHTML = '';
    if (image) { image.removeAttribute('src'); image.style.display = 'none'; }
    if (thumb) { thumb.classList.remove('no-image'); thumb.classList.add('loading'); }
    if (watchBtn) { watchBtn.disabled = true; watchBtn.style.opacity = '.6'; }
    overlay.style.display = 'flex';
    overlay.setAttribute('aria-hidden', 'false');
    const shell = document.getElementById('appShell');
    if (shell) { shell.style.visibility = 'hidden'; shell.style.display = 'none'; }
    document.body.style.overflow = 'hidden';
}

/* ==========================================
   SHARED VIDEO PATH
   Uses the existing video ID to identify the card without fetching its stream.
========================================== */
function getSharedVideoPathId() {
    const rawPath = window.location.pathname.replace(/^\/+|\/+$/g, '');
    if (!rawPath || /^index(?:\.html)?$/i.test(rawPath)) return '';
    let decodedPath = rawPath;
    try { decodedPath = decodeURIComponent(rawPath); } catch (e) {}
    const pathParts = decodedPath.split('/').filter(Boolean);
    return String(pathParts[pathParts.length - 1] || '').trim().replace(/^--+/, '');
}

function isSharedVideoDismissed() {
    const id = getSharedVideoPathId();
    if (!id) return false;
    try { return sessionStorage.getItem('terastream_shared_dismissed:' + id) === '1'; } catch (e) { return false; }
}

function dismissSharedVideoModal() {
    const id = sharedVideoId || getSharedVideoPathId();
    if (id) {
        try { sessionStorage.setItem('terastream_shared_dismissed:' + id, '1'); } catch (e) {}
    }
    closeSharedVideoModal();
}

function isSharedVideoPath() {
    const rawPath = window.location.pathname.replace(/^\/+|\/+$/g, '');
    return !!rawPath && !/^index(?:\.html)?$/i.test(rawPath);
}

function handleSharedVideoPath() {
    const rawPath = window.location.pathname.replace(/^\/+|\/+$/g, '');
    if (!rawPath || rawPath === 'index.html') return;

    if (isSharedVideoDismissed()) {
        sharedVideoPathPending = false;
        const shell = document.getElementById('appShell');
        if (shell) { shell.style.visibility = ''; shell.style.display = ''; }
        return;
    }

    showSharedVideoLoading();

    // Shared links intentionally use the website origin followed by the original
    // source URL, for example:
    // http://gigastream.kesug.com/https://teraviralhub.com/1584577
    let decodedPath = rawPath;
    try { decodedPath = decodeURIComponent(rawPath); } catch (e) {}
    if (/^index(?:\.html)?$/i.test(decodedPath)) return;

    const sharedSourceUrl = /^https?:\/\//i.test(decodedPath)
        ? decodedPath.replace(/\/+$/, '')
        : '';
    const pathParts = decodedPath.split('/').filter(Boolean);
    const lastPart = pathParts[pathParts.length - 1] || '';
    if (!lastPart) return;
    sharedVideoId = lastPart;
    const idx = findSharedVideoIndex(/^https?:\/\//i.test(decodedPath) ? decodedPath : window.location.origin + '/' + decodedPath);
    if (idx < 0) {
        closeSharedVideoModal();
        showToast('Video not found. Please check the shared link.','error');
        return;
    }

    sharedVideoPathPending = false;
    showSharedVideoModal(idx);
}

/* ==========================================
   SHARED VIDEO POPUP
   Shows the selected video before opening the single in-app player.
========================================== */
function showSharedVideoModal(index) {
    const video = allVideos[index];
    const overlay = document.getElementById('sharedVideoModalOverlay');
    const image = document.getElementById('sharedVideoModalImage');
    const title = document.getElementById('sharedVideoModalName');
    const modalTitle = document.getElementById('sharedVideoModalTitle');
    const meta = document.getElementById('sharedVideoModalMeta');
    const watchBtn = document.getElementById('sharedVideoWatchBtn');
    if (!video || !overlay || !watchBtn) return;

    const name = video.name || 'Untitled';
    if (modalTitle) modalTitle.textContent = 'Video';
    if (title) title.textContent = name;
    if (image) {
        image.onerror = () => {
            image.style.display = 'none';
            const thumb = document.getElementById('sharedVideoModalThumb');
            if (thumb) thumb.classList.add('no-image');
        };
        const thumb = document.getElementById('sharedVideoModalThumb');
        if (thumb) { thumb.classList.remove('no-image'); thumb.classList.remove('loading'); }
        image.src = video.thumbnail || '';
        image.style.display = video.thumbnail ? 'block' : 'none';
        if (!video.thumbnail && thumb) thumb.classList.add('no-image');
    }
    if (meta) {
        const parts = [];
        if (video.duration) parts.push('<span><i class="fas fa-clock"></i> ' + escHtml(video.duration) + '</span>');
        if (video.size_formatted) parts.push('<span><i class="fas fa-hdd"></i> ' + escHtml(video.size_formatted) + '</span>');
        if (video.viewCount > 0) parts.push('<span><i class="fas fa-eye"></i> ' + escHtml(formatViewCount(parseInt(video.viewCount) || 0)) + ' views</span>');
        meta.innerHTML = parts.join('');
    }

    watchBtn.disabled = false;
    watchBtn.style.opacity = '';
    watchBtn.onclick = () => {
        closeSharedVideoModal();
        if (!currentUser) {
            showLoginModal(() => fetchAndOpenDetail(index));
            return;
        }
        fetchAndOpenDetail(index);
    };

    overlay.style.display = 'flex';
    overlay.setAttribute('aria-hidden', 'false');
    if (isSharedVideoPath()) {
        const shell = document.getElementById('appShell');
        if (shell) shell.style.visibility = 'hidden';
    }
    document.body.style.overflow = 'hidden';
}

function closeSharedVideoModal() {
    const overlay = document.getElementById('sharedVideoModalOverlay');
    if (overlay) {
        overlay.style.display = 'none';
        overlay.setAttribute('aria-hidden', 'true');
    }
    document.body.style.overflow = '';
    const shell = document.getElementById('appShell');
    if (shell) {
        shell.style.visibility = '';
        shell.style.display = '';
    }
}

/* ==========================================
   OPEN DETAIL
========================================== */
function openDetail(index) {
    currentVideoIndex = index;
    showSharedVideoModal(index);
}

/* ==========================================
   DOWNLOAD
========================================== */
function triggerDownload(index) {
    const video = allVideos[index];
    let url = '';
    if (video.fast_dlink) url = video.fast_dlink;
    else if (video.fast_stream_url && Object.keys(video.fast_stream_url).length) {
        const keys = Object.keys(video.fast_stream_url);
        url = video.fast_stream_url[keys[keys.length-1]] || '';
    } else if (video.stream_url) url = video.stream_url;
    else if (video.downloadUrl) url = video.downloadUrl;
    if (!url) { showToast('No download link available.','error'); return; }
    const a = document.createElement('a');
    a.href = url; a.target = '_blank'; a.rel = 'noopener noreferrer';
    a.download = (video.name||'video').replace(/[^a-zA-Z0-9._-]/g,'_');
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    showToast('Download started.','success');
}
function downloadCurrent() {
    if (currentVideoIndex < 0) return;
    if (!currentUser) {
        showLoginModal(() => triggerDownload(currentVideoIndex));
        return;
    }
    triggerDownload(currentVideoIndex);
}

/* ==========================================
   REQ #9: SHARE — shares WebsiteURL/VideoID (NOT source URL)
========================================== */
function buildShareUrl(index) {
    const video = allVideos[index];
    if (!video) return window.location.href;
    const websiteBase = 'https://gigastream.kesug.com';
    const videoId = String(video.videoId || video.video_id || video.id || video._fbKey || '').trim().replace(/^--+/, '');
    return videoId ? (websiteBase + '/' + encodeURIComponent(videoId)) : websiteBase;
}
function shareVideo(index) {
    if (index < 0 || !allVideos[index]) return;
    const shareUrl = buildShareUrl(index);
    const input = document.getElementById('shareLinkInput');
    const overlay = document.getElementById('shareModalOverlay');
    if (input) input.value = shareUrl;
    if (overlay) {
        overlay.classList.add('active');
        overlay.setAttribute('aria-hidden','false');
        overlay.removeAttribute('hidden');
        /* Keep the share action as a real popup even if the external stylesheet is delayed/not cached. */
        overlay.style.display = 'flex';
        overlay.style.position = 'fixed';
        overlay.style.inset = '0';
        overlay.style.zIndex = '99999';
        overlay.style.display = 'flex';
        overlay.style.alignItems = 'flex-end';
        overlay.style.justifyContent = 'center';
        overlay.style.padding = '0 10px 12px';
        overlay.style.background = 'rgba(0,0,0,.72)';
        overlay.style.backdropFilter = 'blur(10px)';
        overlay.style.webkitBackdropFilter = 'blur(10px)';

        const box = overlay.querySelector('.share-modal-box');
        if (box) {
            box.style.width = 'min(620px,100%)';
            box.style.boxSizing = 'border-box';
            box.style.background = '#111116';
            box.style.border = '1px solid rgba(255,255,255,.11)';
            box.style.borderRadius = '28px';
            box.style.padding = '25px 20px 28px';
            box.style.boxShadow = '0 25px 70px rgba(0,0,0,.55)';
        }
    }
}
function closeShareModal() {
    const overlay = document.getElementById('shareModalOverlay');
    if (overlay) {
        overlay.classList.remove('active');
        overlay.setAttribute('aria-hidden','true');
        overlay.style.display = 'none';
    }
}
function copyShareLink() {
    const input = document.getElementById('shareLinkInput');
    if (!input || !input.value) return;
    const copied = () => showToast('Share link copied!','success');
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(input.value).then(copied).catch(() => fallbackCopyShareUrl(input.value));
    } else {
        fallbackCopyShareUrl(input.value);
    }
}
function fallbackCopyShareUrl(shareUrl) {
    const textarea = document.createElement('textarea');
    textarea.value = shareUrl;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try {
        const copied = document.execCommand('copy');
        showToast(copied ? 'Share link copied!' : 'Could not copy share link.', copied ? 'success' : 'error');
    } catch (e) {
        showToast('Could not copy share link.','error');
    }
    document.body.removeChild(textarea);
}
function shareVia(type) {
    const input = document.getElementById('shareLinkInput');
    if (!input || !input.value) return;
    const url = encodeURIComponent(input.value);
    const text = encodeURIComponent('Check out this video');
    let target = '';
    if (type === 'whatsapp') target = 'https://wa.me/?text=' + text + '%20' + url;
    else if (type === 'telegram') target = 'https://t.me/share/url?url=' + url + '&text=' + text;
    else if (type === 'x') target = 'https://twitter.com/intent/tweet?text=' + text + '&url=' + url;
    else if (type === 'facebook') target = 'https://www.facebook.com/sharer/sharer.php?u=' + url;
    if (target) window.open(target, '_blank', 'noopener,noreferrer');
}
function shareCurrent() { if (currentVideoIndex >= 0) shareVideo(currentVideoIndex); }
function saveCurrent() {
    if (currentVideoIndex < 0) return;
    saveVideo(currentVideoIndex, document.getElementById('detailSaveBtn'));
}

/* ==========================================
   REQ #8: COPY — copies the actual video link (not homepage URL)
========================================== */
function copyVideoUrl(index) {
    const video = allVideos[index];
    // Copy the actual link for this specific video, never the homepage URL.
    const url = video.sourceUrl || video.source_url || video.downloadUrl || video.download_url || '';
    if (!url) {
        showToast('Video link is not available.','error');
        return;
    }
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(url)
            .then(() => showToast('Video link copied!','success'))
            .catch(() => fallbackCopyVideoUrl(url));
    } else {
        fallbackCopyVideoUrl(url);
    }
}
function fallbackCopyVideoUrl(url) {
    const textarea = document.createElement('textarea');
    textarea.value = url;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try {
        const copied = document.execCommand('copy');
        showToast(copied ? 'Video link copied!' : 'Copy failed.', copied ? 'success' : 'error');
    } catch (e) {
        showToast('Copy failed.','error');
    }
    document.body.removeChild(textarea);
}
function copyCurrentUrl() { if (currentVideoIndex >= 0) copyVideoUrl(currentVideoIndex); }

/* ==========================================
   TOAST
========================================== */
function showToast(message, type) {
    type = type || 'info';
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'toast ' + type;
    const icons = { success:'fas fa-check-circle', error:'fas fa-times-circle', info:'fas fa-info-circle' };
    toast.innerHTML = `<i class="${icons[type]||icons.info}"></i><span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 3200);
}

/* ==========================================
   UTILS
========================================== */
function debounce(fn, delay) {
    let timer;
    return function(...args) { clearTimeout(timer); timer = setTimeout(() => fn.apply(this, args), delay); };
}

/* Bind UI handlers once; the HTML contains no inline JavaScript. */
bindEvents();
